@extends('Style.content')

@section('title')

HETADATAIN|DASHBOARD

@endsection

@section('content')




@endsection

@section('scripts')

@endsection
